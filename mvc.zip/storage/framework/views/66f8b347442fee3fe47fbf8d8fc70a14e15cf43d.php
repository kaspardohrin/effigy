

<?php $__env->startSection('comments'); ?>

  <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <li>
      <?php echo e($comments->comment); ?>

    </li>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <li>Such empty.</li>
  <?php endif; ?>
</ul>

<form action="/posts" method="POST">
  <?php echo csrf_field(); ?>
  <div class="block">
    <input
        type="text"
        name="comment"
        placeholder="Comment.."
    >
    <button>
      Reply
    </button>
  </div>
</form>

<a href="/posts">&larr; Back</a>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('posts.show', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/comments/show.blade.php ENDPATH**/ ?>