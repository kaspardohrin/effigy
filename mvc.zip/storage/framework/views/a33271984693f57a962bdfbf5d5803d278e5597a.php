

<?php $__env->startSection('content'); ?>
  <!-- <?php if(auth()->user()->admin): ?>
    <h1>Users</h1>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <p><?php echo e($user->name); ?>, <?php echo e($user->admin); ?></p>
      <form action="/user/<?php echo e($user->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button>
          BAN &rarr;
        </button>
      </form>
      <form action="/user/<?php echo e($user->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <button>
          <?php if($user->admin): ?>
            Downgrade &rarr;
          <?php else: ?>
            Upgrade &rarr;
          <?php endif; ?>
        </button>
      </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?> -->

  <?php if(auth()->user()->admin): ?>
    <h1>Users</h1>

    <ul style="list-style: none;">
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div style="margin-bottom: 24px;">
          <li>Username: <?php echo e($user->name); ?></li>
          <li>Admin: <?php echo e($user->admin); ?></li>

          <div style="display: flex; flex-direction: row;">
            <form action="/user/<?php echo e($user->id); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('put'); ?>

              <?php if($user->admin): ?>
                <button style="all: unset; color: red; margin-right: 10px; cursor: pointer">
                  &#9759; Downgrade
                </button>
              <?php else: ?>
                <button style="all: unset; color: green; margin-right: 10px; cursor: pointer">
                  &#9757; Upgrade
                </button>
              <?php endif; ?>
            </form>
            <form action="/user/<?php echo e($user->id); ?>" method="POST">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
              <button style="all: unset; color: red; margin-right: 10px; cursor: pointer">
                &#9760; Ban
              </button>
            </form>
          </div>

        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

  <?php endif; ?>

  <div style="height: 32px;" ></div>

  <h1>Posts</h1>

  <a
    style="float: right;"
    href="posts/create">
    &#9998; NEW
  </a>

  <p>Amount of posts: <b><?php echo e(count($posts)); ?></b></p>

  <div style="display: flex; flex-wrap: wrap;">

    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      <div style="border: 1px solid #5f5f5f50; width: 250px; margin: 0 12.5px 15px 12.5px">

        <p style="font-weight: bold;"><?php echo e($post->title); ?></p>
        <!-- <p><?php echo e($post->description); ?></p> -->
        <img
            style="max-width: 248px; max-height: 250px;"
            class="post-image"
            src="<?php echo e(asset($post->path)); ?>"
            alt="image"
        >

        <p>Likes: <?php echo e(count($post->likes)); ?></p>
        <p>Comments: <?php echo e(count($post->comments)); ?></p>

        <div style="display: flex; flex-direction: row; flex-wrap: wrap;">
          <a href="posts/<?php echo e($post->id); ?>">View &rarr;</a>

          <!-- activation/deactivation logic -->
          <form style="margin-left: auto;" action="/posts/activate/<?php echo e($post->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('put'); ?>
            <?php if($post->hidden): ?>
              <button style="all: unset; color: green; margin-right: 10px; cursor: pointer">
                &#9745; Show
              </button>
            <?php else: ?>
              <button style="all: unset; color: red; margin-right: 10px; cursor: pointer">
                &#9746; Hide
              </button>
            <?php endif; ?>
          </form>

          <a style="margin-left: auto;" href="posts/<?php echo e($post->id); ?>/edit">&#9998; Edit</a>

          <!-- post deletion logic -->
          <form style="margin-left: auto;" action="/posts/<?php echo e($post->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button style="all: unset; color: red; margin-right: 10px; cursor: pointer">
              &#9747; Delete
            </button>
          </form>
        </div>

      </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/user/index.blade.php ENDPATH**/ ?>