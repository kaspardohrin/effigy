

<?php $__env->startSection('content'); ?>
<h1>homepage</h1>

<div style="display: flex; flex-direction: column;">
  <a href="/profile"><h3>Profile</h3></a>

  <a href="/posts"><h3>Gallery</h3></a>
<div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/index.blade.php ENDPATH**/ ?>