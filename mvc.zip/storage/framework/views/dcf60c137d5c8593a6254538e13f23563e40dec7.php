

<?php $__env->startSection('content'); ?>
<h1>Create Post</h1>

<?php if(!auth()->user()->worthy()): ?>

  <p>You'll need to have liked or disliked atleast 5 posts before being allowed to create you own posts!</p>

<?php else: ?>

  <form action="/posts" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="block">
      <input
        type="file"
        name="image"
      >
      <input
        type="text"
        name="title"
        placeholder="Post title.."
      >
      <input
        type="text"
        name="description"
        placeholder="Post description.."
      >

      <button>
        Submit
      </button>
    </div>
  </form>

  <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <ul>
      <li style="color:red;">
        <?php echo e($error); ?>

      </li>
    </ul>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <?php endif; ?>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/posts/create.blade.php ENDPATH**/ ?>