

<?php $__env->startSection('content'); ?>
<h1>Update Post</h1>

<form action="/posts/<?php echo e($post->id); ?>" method="POST">
  <?php echo csrf_field(); ?>
  <?php echo method_field('PUT'); ?>
  <div class="block">
    <input
      type="text"
      name="title"
      value="<?php echo e($post->title); ?>"
    >
    <input
      type="text"
      name="description"
      value="<?php echo e($post->description); ?>"
    >

    <button>
      Submit &rarr;
    </button>
  </div>
</form>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/posts/edit.blade.php ENDPATH**/ ?>