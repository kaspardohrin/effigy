

<?php $__env->startSection('content'); ?>
<h1>Posts</h1>

<p> <?php echo e($item); ?> </p>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/posts/detail.blade.php ENDPATH**/ ?>