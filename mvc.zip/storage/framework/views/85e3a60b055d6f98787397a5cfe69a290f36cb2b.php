<!-- Navigation -->
<nav class="top-menu-container">
    <div class="logo-header">
        <a href="">
            <img
                src="<?php echo e(asset('img/octo.jpg')); ?>"
                alt="logo effigy"
                title="logo effigy"
            />
        </a>
    </div>

    <ul>
        <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>">
            <a href="/">Home</a>
        </li>
        <li class="<?php echo e(request()->is('posts') ? 'active' : ''); ?>">
            <a href="/posts">Posts</a>
        </li>
    </ul>
</nav><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/layouts/nav.blade.php ENDPATH**/ ?>