

<?php $__env->startSection('content'); ?>
  <a href="/posts">&larr; Back</a>

  <h1> <?php echo e($post->title); ?> </h1>
  <p> <?php echo e($post->description); ?> </p>

  <img style="width: 100%;" src="<?php echo e(asset($post->path)); ?>" alt="image">

  <div style="display: flex; flex-direction: row; margin: 5px 0;">
    <p>Likes: <?php echo e(count($post->likes)); ?></p>
    <!-- add like -->
    <form action="/likes" method="POST">
      <?php echo csrf_field(); ?>
      <div class="block">
        <input
        type="hidden"
        name="post_id"
        value="<?php echo e($post->id); ?>"
        >
        <button style="all: unset; color: green; padding: 0 5px; margin-left: 5px; cursor: pointer;">
          &uarr;
        </button>
      </div>
    </form>


    <!-- remove like -->
    <form action="/likes/<?php echo e($post->id); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('delete'); ?>
      <button style="all: unset; color: red; padding: 0 5px; margin-left: 5px; cursor: pointer;">
        &darr;
      </button>
    </form>

    <!-- if user is the owner of the post -->
    <?php if(auth()->user()->id == $post->user_id): ?>
      <a style="margin: 0 5px 0 auto" href="/posts/<?php echo e($post->id); ?>/edit">&#9998; Edit</a>

      <!-- activation/deactivation logic -->
      <form style="margin-left: auto;" action="/posts/activate/<?php echo e($post->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('put'); ?>
        <?php if($post->hidden): ?>
          <button style="all: unset; color: green; margin-right: 10px; cursor: pointer">
            &#9745; Show
          </button>
        <?php else: ?>
          <button style="all: unset; color: red; margin-right: 10px; cursor: pointer">
            &#9746; Hide
          </button>
        <?php endif; ?>
      </form>
    <?php endif; ?>

    <?php if(auth()->user()->id == $post->user_id || auth()->user()->admin): ?>
    <form style="margin-left: auto;" action="/posts/<?php echo e($post->id); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('delete'); ?>
      <button style="all: unset; color: red; cursor: pointer;">
        &#9747; Delete
      </button>
    </form>
    <?php endif; ?>
  </div>

  <!-- list all comments on currently selected post -->
  <p>Comments:</p>

  <p>Amount of comments: <?php echo e(count($post->comments)); ?></p>

  <ul>
    <?php $__empty_1 = true; $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <li style="display: flex; flex-direction: row;">

        <p style="">
          <?php echo e($comments->comment); ?>

        </p>

        <!-- delete comment -->
        <?php if($comments->user_id == auth()->user()->id || auth()->user()->admin): ?>
          <form style="margin-left: auto;" action="/comments/<?php echo e($comments->id); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <button style="all: unset; color: red; cursor: pointer;">
              &#9747;
            </button>
          </form>
        <?php endif; ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>Such empty.</p>

      </li>
    <?php endif; ?>
  </ul>

  <ul>
    <!-- add comment -->
    <form action="/comments" method="POST">
      <?php echo csrf_field(); ?>
      <div class="block">
        <input
            type="text"
            name="comment"
            placeholder="Comment.."
        >
        <input
          type="hidden"
          name="post_id"
          value="<?php echo e($post->id); ?>"
        >
        <button>
          Reply
        </button>
      </div>
    </form>
  </ul>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/posts/show.blade.php ENDPATH**/ ?>