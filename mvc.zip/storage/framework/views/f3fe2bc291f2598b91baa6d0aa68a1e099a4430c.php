

<?php $__env->startSection('content'); ?>
  <h1>Posts</h1>

  <div style="display: flex; flex-direction: row; margin-bottom: 20px;">

    <p style="margin: auto 0;">Amount of posts: <b><?php echo e(count($posts)); ?></b></p>

    <form style="margin: auto auto; display: flex; flex-direction: row;" action="/search" method="post">
      <?php echo csrf_field(); ?>
      <label style="margin: auto 5px;" for="body">Select:</label>
      <select for="tags" name="tag">Select genre(s):
          <option value="" selected>-</option>
        <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($tag->tag); ?>"><?php echo e($tag->tag); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <div>
        <label style="margin: auto 0 auto 5px;" for="body">Search:</label>
        <input style="margin: auto;" type="text" name="term" id="term" placeholder="Enter your search term" value="<?php echo e(old('text')); ?>">
      </div>

      <button type="submit" style="margin: auto 5px;">Search</button>
    </form>

    <a
      style="margin: auto 0;"
      href="posts/create">
      &#9998; NEW
    </a>
  </div>

  <div style="display: flex; flex-wrap: wrap;">

    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

      <div style="border: 1px solid #5f5f5f50; width: 250px; margin: 0 12.5px 15px 12.5px">

        <p style="font-weight: bold;"><?php echo e($post->title); ?></p>
        <!-- <p><?php echo e($post->description); ?></p> -->
        <img
            style="max-width: 248px; max-height: 250px;"
            class="post-image"
            src="<?php echo e(asset($post->path)); ?>"
            alt="image"
        >
        <!-- <div style="display: flex;"> -->
          <p>Tag: <?php echo e($post->tag); ?></p>
          <p>Likes: <?php echo e(count($post->likes)); ?></p>
          <p>Comments: <?php echo e(count($post->comments)); ?></p>
          <a href="posts/<?php echo e($post->id); ?>">View &rarr;</a>
        <!-- </div> -->

      </div>

      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p>There doesn't seem to be any content here</p>

    <?php endif; ?>
  <div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/posts/index.blade.php ENDPATH**/ ?>