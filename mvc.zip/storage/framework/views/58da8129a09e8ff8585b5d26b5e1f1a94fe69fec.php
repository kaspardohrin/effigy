<div class="container-footer">
    <img
        src="<?php echo e(asset('img/icon.png')); ?>"
        alt="logo effigy"
        title="logo effigy"
    />
    <p>EFFIGY</p>
</div><?php /**PATH C:\Users\kaspar\Documents\cmgt\effigy\resources\views/layouts/footer.blade.php ENDPATH**/ ?>