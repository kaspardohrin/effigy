<div class="container-footer">
    <img
        src="{{ asset('img/icon.png') }}"
        alt="logo effigy"
        title="logo effigy"
    />
    <p>EFFIGY</p>
</div>