@extends('layouts.app')

@section('content')
<h1>homepage</h1>

<div style="display: flex; flex-direction: column;">
  <a href="/profile"><h3>Profile</h3></a>

  <a href="/posts"><h3>Gallery</h3></a>
<div>

@endsection